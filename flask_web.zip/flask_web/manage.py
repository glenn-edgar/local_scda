
from functools import wraps
from werkzeug.contrib import authdigest
import flask

from flask import Flask
from flask import render_template,jsonify,request

from app.flow_rate_functions    import *
from app.system_state           import *
from app.statistics_modules     import *
from app.template_support       import *
import os

app = Flask(__name__)
app.config['SECRET_KEY']      = 'dvcxs2r%Acd'
app.config["DEBUG"]           = True
app.template_folder           = 'templates'
app.static_folder             = 'static'
redis_handle_15 = redis.StrictRedis(host='localhost', port=6379, db=15)
redis_handle    = redis.StrictRedis(host='localhost', port=6379 )

flow_rate_functions = FlowRateFunctions( redis_handle_15 )
system_status          = System_Status( redis_handle )
statistics_module      = Statistics_Module(redis_handle)
template_support       = template_support(redis_handle,statistics_module)
  
class FlaskRealmDigestDB(authdigest.RealmDigestDB):
    def requires_auth(self, f):
        @wraps(f)
        def decorated(*args, **kwargs):
            request = flask.request
            if not self.isAuthenticated(request):
                return self.challenge()

            return f(*args, **kwargs)

        return decorated

authDB = FlaskRealmDigestDB('MyAuthRealm')
authDB.add_user('admin', 'password')

from flask import request, session

######################### Set up Static RoutesFiles ########################################

   
  

@app.route('/static/js/<path:filename>')
@authDB.requires_auth
def get_js(filename):
  return app.send_static_file(os.path.join('js', filename))

@app.route('/static/js_library/<path:filename>')
@authDB.requires_auth
def get_js_library(filename):
 return app.send_static_file(os.path.join('js_library', filename))

@app.route('/static/css/<path:filename>')
@authDB.requires_auth
def get_css(filename):
 return app.send_static_file(os.path.join('css', filename))

@app.route('/static/images/<path:filename>')
@authDB.requires_auth
def get_images(filename):
 return app.send_static_file(os.path.join('images', filename))

@app.route('/static/dynatree/<path:filename>')
@authDB.requires_auth
def get_dynatree(filename):
 return app.send_static_file(os.path.join('dynatree', filename))

@app.route('/static/themes/<path:filename>')
@authDB.requires_auth
def get_themes(filename):
 return app.send_static_file(os.path.join('themes', filename))

#@app.route('/static/html/<path:filename>')
#@authDB.requires_auth
#def get_html(filename):
# return render_template(filename)

@app.route('/static/data/<path:filename>')
@authDB.requires_auth
def get_data(filename):
  return app.send_static_file(os.path.join('data', filename))






@app.route('/ajax/get_status',methods=["GET"])
@authDB.requires_auth
def get_status():
   temp = system_status.get_status()
   return temp


@app.route('/ajax/schedule_data',methods=["GET"])
@authDB.requires_auth
def schedule_data():
   temp = system_status.schedule_data()
   return temp

@app.route('/ajax/mode_change',methods=["POST"])
@authDB.requires_auth
def change_mode():
   json_object = request.json
   temp = system_status.mode_change(json_object)
   return temp


@app.route('/ajax/get_redis_keys',methods=["POST"])
@authDB.requires_auth
def get_redis():
   return_value = {}
   param = request.get_json()

   for i in param:
     
      temp = redis_handle.get( i )
      return_value[i] = temp
      
   return json.dumps( return_value )
   
@app.route('/ajax/set_redis_keys',methods=["POST"])
@authDB.requires_auth
def set_redis():
   return_value = []
   param = request.get_json()
   for i in param.keys():
       redis_handle.set( i,param[i] )
   return json.dumps('SUCCESS')
   


@app.route('/ajax/get_eto_entries',methods=["GET"])
@authDB.requires_auth
def get_eto_entries():
   temp = system_status.get_eto_entries()
   return temp

@app.route('/ajax/save_eto_data',methods=["POST"])
@authDB.requires_auth
def save_eto_data():
   eto_data = request.json
   temp = system_status.save_eto_data( eto_data )
   return temp



@app.route('/ajax/get_queue_entry',methods=["GET"])
@authDB.requires_auth
def get_queue_entry():
   temp = system_status.get_queue_entry()
   return temp


@app.route('/ajax/delete_queue_element',methods=["POST"])
@authDB.requires_auth
def delete_queue_element():
   param = request.json
   temp = system_status.get_queue_entry( param )
   return temp

@app.route('/')
@authDB.requires_auth
def index():
  filename = "control"
  return render_template("control",filename=filename)

 
@app.route('/control/<filename>')
@authDB.requires_auth
def control(filename):
  return render_template("control",filename=filename)



str_prop = {}
str_prop["coil"] = {}
str_prop["coil"]["header"]        = "Recent Coil Current"
str_prop["coil"]["queue"]         = "coil_current_queue"
str_prop["coil"]["limit_low"]     = 0
str_prop["coil"]["limit_high"]    = 20
str_prop["coil"]["scale"]         = 1.
str_prop["coil"]["x_axis"]        = "Time"
str_prop["coil"]["y_axis"]        = "mAmp"
str_prop["plc"] = {}
str_prop["plc"]["header"]         = "Recent Plc Current"
str_prop["plc"]["queue"]          = "plc_current_queue"
str_prop["plc"]["limit_low"]      = -1.
str_prop["plc"]["limit_high"]     = 1
str_prop["plc"]["scale"]          = 1.
str_prop["plc"]["x_axis"]        = "Time"
str_prop["plc"]["y_axis"]        = "mAmp"


@app.route("/ajax/strip_chart/<queue>",methods=["POST"])
@authDB.requires_auth
def get_strip_chart(queue):
   # find element
   scale = 1
   for i in str_prop.keys():
     if str_prop[i]["queue"] == queue:
        scale = str_prop[i]["scale"]
  
   temp = flow_rate_functions.strip_chart(queue,scale)
   return temp


@app.route('/strip_chart/<filename>')
@authDB.requires_auth
def strip_chart(filename):
   if str_prop.has_key(filename ):
       header       = str_prop[filename]["header"]
       queue        = str_prop[filename]["queue"]
       limit_low    = str_prop[filename]["limit_low"]
       limit_high   = str_prop[filename]["limit_high"]
       x_axis       = str_prop[filename]["x_axis"]
       y_axis       = str_prop[filename]["y_axis"]
       return render_template("strip_chart", queue= queue, header_name = header,limit_low = limit_low,limit_high=limit_high,x_axis=x_axis,y_axis=y_axis )


sel_prop = {}
sel_prop["flow"] = {}
sel_prop["flow"]["header"]        = "Flow Rate History GPM"
sel_prop["flow"]["queue"]          = "/ajax/sel_strip_chart/redis_flow_queue_"
sel_prop["flow"]["limit_low"]     = 0
sel_prop["flow"]["limit_high"]    = 40
sel_prop["flow"]["sel_function"]  = '/ajax/flow_sensor_names'
sel_prop["flow"]["sel_label"]     = "Flow Sensors"
sel_prop["flow"]["x_axis"]        = "Time"
sel_prop["flow"]["y_axis"]        = "GPM"
@app.route('/ajax/flow_sensor_names',methods=["GET"])
@authDB.requires_auth
def get_flow_sensor_names():
   temp = flow_rate_functions.get_flow_rate_sensor_names()
   return temp

@app.route('/ajax/sel_strip_chart/<queue>',methods=["POST"])
@authDB.requires_auth
def sel_strip_chart(queue):

  
   temp = flow_rate_functions.sel_chart( queue )
   return temp

@app.route('/sel_chart/<filename>',methods=["GET"])
@authDB.requires_auth
def sel_chart(filename):
   if sel_prop.has_key(filename ):
       header_name   = sel_prop[filename]["header"]
       queue         = sel_prop[filename]["queue"]
       limit_low     = sel_prop[filename]["limit_low"]
       limit_high    = sel_prop[filename]["limit_high"]
       sel_function  = sel_prop[filename]["sel_function"]
       sel_label     = sel_prop[filename]["sel_label"]
       x_axis        = sel_prop[filename]["x_axis"]
       y_axis        = sel_prop[filename]["y_axis"]

    
       return render_template("sel_chart", queue= queue, header_name = header_name,limit_low = limit_low,limit_high=limit_high, 
                               sel_function = sel_function,sel_label = sel_label, x_axis=x_axis,y_axis=y_axis )


@app.route('/overall_flow_statistics/<int:flow_id>/<int:schedule_id>',methods=["GET"])
@authDB.requires_auth
def overall_flow_statistics(flow_id,schedule_id):
       schedule_list = statistics_module.schedule_data.keys()
       sensor_name  = statistics_module.sensor_names[flow_id]
       max_flow_rate = 33
       canvas_list = template_support.generate_canvas_list( schedule_list[schedule_id], flow_id   ) 
       return render_template("overall_flow_statistics", 
                               schedule_id=schedule_id,
                               flow_id=flow_id,  
                               header_name="Flow Overview  Max Flow Rate "+str(max_flow_rate), 
                               flow_sensors = statistics_module.sensor_names,
                               schedule_list = schedule_list, 
                               max_flow_rate = max_flow_rate, 
                               canvas_list= canvas_list )

@app.route('/overall_current_statistics/<int:schedule_id>',methods=["GET"])
@authDB.requires_auth
def overal_current_statistics(schedule_id):
       max_current = 20
       schedule_list = statistics_module.schedule_data.keys()
       canvas_list = template_support.generate_current_canvas_list( schedule_list[schedule_id]  ) 
       return render_template("overall_current_statistics", 
                               schedule_id=schedule_id,
                               header_name="Valve Current Overview  Max Current "+str(max_current),
                               schedule_list = schedule_list, 
                               max_flow_rate = max_current, 
                               canvas_list= canvas_list )


display_control = []
temp  = {}
temp["name"]              = "Average Flow"
temp["flow_sensor_flag"]  = True
temp["time_step_flag"]    = False
temp["ajax_path"]      = "-----------TBD----------"
temp['limit_low']      = 0
temp['limit_high']     = 40
temp['x_axis']         = "Time"
temp['y_axis']         = "GPM"
temp["time_generation"] = False
temp["average_generation"] = True
temp["label_array"]        =  ['Time',"GPM"]

display_control.append(temp)
temp  = {}
temp["name"]               = "Time Series Flow"
temp["flow_sensor_flag"]   = True
temp["time_step_flag"]     = True
temp["ajax_path"]          = "-----------TBD----------"
temp['limit_low']          = 0
temp['limit_high']         = 40
temp['x_axis']             = "Time"
temp['y_axis']             = "GPM"
temp["time_generation"]    = True
temp["average_generation"] = False
temp["label_array"]        =  ['Time', 'Flow Rate 1',"Flow Rate 2","Flow Rate 3","Flow Rate 4","Flow Rate 5"]

display_control.append(temp)
temp  = {}
temp["name"]              = "Total Flow"
temp["flow_sensor_flag"]  = True
temp["time_step_flag"]    = False
temp["ajax_path"]      = "-----------TBD----------"
temp['limit_low']      = 1
temp['limit_high']     = 10000
temp['x_axis']         = "Time"
temp['y_axis']         = "Gallons"
temp["time_generation"]    = False
temp["average_generation"] = True
temp["label_array"]        =  ['Time',"Gallons"]

display_control.append(temp)
temp  = {}
temp["name"]              = "Average Current"
temp["flow_sensor_flag"]  = False
temp["time_step_flag"]    = False
temp["ajax_path"]      = "-----------TBD----------"
temp['limit_low']      = 0
temp['limit_high']     = 20
temp['x_axis']         = "Time"
temp['y_axis']         = "mAmp"
temp["time_generation"]    = False
temp["average_generation"] = True

temp["label_array"]        =  ['Time',"mAmp"]

display_control.append(temp)
temp  = {}
temp["name"]              = "Time Series Current"
temp["flow_sensor_flag"]  = False
temp["time_step_flag"]    = True
temp["ajax_path"]      = "-----------TBD----------"
temp['limit_low']      = 0
temp['limit_high']     = 20
temp['x_axis']         = "Time"
temp['y_axis']         = "mAmp"

temp["time_generation"]    = True
temp["average_generation"] = False
temp["label_array"]        =  ['Time', 'Coil Current 1',"Coil Current 2","Coil Current 3","Coil Current 4","Coil Current 5"]

display_control.append(temp)

chart_list = []
for i in display_control:
   chart_list.append(i["name"])

 

@app.route('/detail_statistics_ajax/<int:chart_type>/<int:flow_sensor_id>/<int:schedule_id>/<int:step_id>/<int:time_id>',methods=["GET"])
@authDB.requires_auth
def detail_statistics_ajax(chart_type, flow_sensor_id,schedule_id,step_id,time_id):
   if chart_type == 0:
       schedule_name = statistics_module.schedule_data.keys()[schedule_id]
       sensor_name   = statistics_module.flow_rate_sensor_names[ flow_sensor_id ]
      
       return_value  = statistics_module.get_average_flow_data_queue( step_id, sensor_name, schedule_name )

   if chart_type == 1:
       schedule_name = statistics_module.schedule_data.keys()[schedule_id]
       sensor_name   = statistics_module.flow_rate_sensor_names[ flow_sensor_id ]
       return_value  = statistics_module.get_time_index_flow( time_id, step_id, sensor_name, schedule_name )
   if chart_type == 2:
       schedule_name = statistics_module.schedule_data.keys()[schedule_id]
       sensor_name   = statistics_module.flow_rate_sensor_names[ flow_sensor_id ]
       return_value  = statistics_module.get_total_flow_data( step_id, sensor_name, schedule_name )

   if chart_type == 3:
       schedule_name = statistics_module.schedule_data.keys()[schedule_id]
       return_value  = statistics_module.get_average_current_data_queue( step_id,  schedule_name )


   if chart_type == 4:
       schedule_name = statistics_module.schedule_data.keys()[schedule_id]
       return_value  = statistics_module.get_time_index_current( time_id, step_id,schedule_name )
   
   return_value = json.dumps(return_value)
   return return_value


@app.route('/detail_statistics/<int:chart_type>/<int:flow_sensor_id>/<int:schedule_id>/<int:step_id>/<int:time_id>',methods=["GET"])
@authDB.requires_auth
def detail_1(chart_type, flow_sensor_id,schedule_id,step_id,time_id):

       if chart_type < 0:
           chart_type = 0
       if chart_type > len(display_control)-1:
           chart_type = len(display_control)-1
          
       chart_data        = display_control[ chart_type ]
       schedule_list     = statistics_module.schedule_data.keys()
       
       if schedule_id > len(schedule_list)-1:
           schedule_id = len(schedule_list)-1
       
       logscale = False
       step_number       = statistics_module.schedule_data[ schedule_list[schedule_id] ]["step_number"]
       conversion_factor = statistics_module.conversion_rate[ flow_sensor_id ]
       if step_id > step_number-1:
          step_id = step_number-1
       if time_id > 50:
           time_id = 50
       flow_sensors      = statistics_module.flow_rate_sensor_names
       if chart_type == 0:
            legend_name = "Flow Meter: "+flow_sensors[flow_sensor_id]+"     <br>Schedule:  "+schedule_list[schedule_id]+" <br>Step Number:  "+ str(step_id+1)
       if chart_type == 1:
            legend_name = "Flow Meter: "+flow_sensors[flow_sensor_id]+"     <br>Schedule:  "+schedule_list[schedule_id]+" <br>Step Number:  "+ str(step_id+1) +" <br>Time Index:  "+ str(time_id+1)

       if chart_type == 2:
            legend_name = "Flow Meter: "+flow_sensors[flow_sensor_id]+"     <br>Schedule:  "+schedule_list[schedule_id]+" <br>Step Number:  "+ str(step_id+1)
            logscale = True

       if chart_type == 3:
            legend_name = "Coil Current:<br>Schedule:  "+schedule_list[schedule_id]+" <br>Step Number:  "+ str(step_id+1) 
            conversion_factor = 1.0

       if chart_type == 4:
            legend_name = "Coil Current:<br>Schedule:  "+schedule_list[schedule_id]+" <br>Step Number:  "+ str(step_id+1) +" <br>Time Index:  "+ str(time_id+1)
            conversion_factor = 1.0
       
    
       return render_template(  "detail_statistics",
                                logscale              = logscale,
                                legend_name           = legend_name,
                                conversion_factor     = conversion_factor,
                                chart_list            = chart_list,
                                chart_data            = chart_data,
                                chart_type            = chart_type,
                                flow_sensor_id        = flow_sensor_id,
                                schedule_id           = schedule_id,
                                step_id               = step_id,
                                time_id               = time_id,
                                header_name           = chart_data["name"],
                                schedule_list         = schedule_list,
                                flow_sensors          = flow_sensors,
                                step_number           = step_number ,
                                label_array           = chart_data["label_array"] )

if __name__ == '__main__':
  app.run(use_reloader=True, host='0.0.0.0',port=80 )
        #ssl_context=('/media/mmc1/new_python/flask_web/server.crt', '/media/mmc1/new_python/flask_web/server.key'))
