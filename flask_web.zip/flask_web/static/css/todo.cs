.done-true {
  text-decoration: line-through;
  color: grey;
}
