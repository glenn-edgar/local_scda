(function($){
	
	$.fn.bullet = function(params) { //Create the bullet plugin.
		
		params = $.extend({
							theWidth: this.width(),
							minValue: 0,
							maxValue: 100,
							featuredMeasure: 50,
							numberTicks: 40 //Specify the number of ticks between the first and last - unused at the moment.  (A) - add.
							}, params);		
		
                
		//Set values
		var scaleLength = params.maxValue - params.minValue;
		var chartWidth = this.width()-100; // 15px padding * 2 (for each side of the chart)
		var chartHeight = this.height();
		var eachUnit = chartWidth/scaleLength;
                
		var featuredLength = eachUnit * params.featuredMeasure;
		var comp1pos = eachUnit * params.compMeasure1;
		var qual1pos = eachUnit * params.qualScale1;
                
		//Set context
		var context = this[0].getContext("2d"); //Get the drawing context.
		context.font="15px sans-serif";
		//Drawing routine
		//Note to self:  Decimal values are percentages of the canvas element as defined in sketches.
		
		//Draw chart background (half of the canvas height)
		context.fillStyle = "Grey";
            
		context.fillRect(70,0,chartWidth,chartHeight *.95);

		//Draw qualitative scale (half of the canvas height)
		if (params.qualScale1) {
			context.fillStyle = params.qualScale1Color
			context.fillRect(70, 0,qual1pos,chartHeight*.95);
		}
	        
		//Comparative measure 1.  Only show if the parameter is provided.
		if (params.compMeasure1) {
			context.fillStyle = "Red";
			context.fillRect(100+comp1pos-1.5,chartHeight * 0.08,3,chartHeight*0.34); //1.5 is half the width of the featured marker.
		}
	        
		//Featured measure - appears in front of the comparative measure, according to the specification.
		context.fillStyle= 'Red'
                var featuredLength = eachUnit * params.featuredMeasure[0];
		context.fillRect(70,chartHeight * 0.625,featuredLength,chartHeight * 0.25);
                context.fillStyle= 'Blue'
                var featuredLength = eachUnit * params.featuredMeasure[1];
                context.fillRect(70,chartHeight * 0.375,featuredLength,chartHeight * 0.25);
                context.fillStyle= 'Green'
                var featuredLength = eachUnit * params.featuredMeasure[2];
                context.fillRect(70,chartHeight * 0.125,featuredLength,chartHeight * 0.25);
               

		//Draw ticks and labels.  Will need to calculate how they appear on the chart and add some padding (15-20px on either side).
		//context.fillStyle = "Red";
		//context.fillRect(15,chartHeight * 0.5, 1, chartHeight * 0.20);
		//context.fillRect(14+chartWidth,chartHeight * 0.5,1,chartHeight * 0.20);
		//context.fillRect(14+(chartWidth*0.5),chartHeight * 0.5,1,chartHeight * 0.20);
		context.fillStyle = "Black"
		//Labels (beginning and end of scale)
		context.textAlign = "left";
		//context.fillText(params.minValue,16,(chartHeight * 0.70)+10); //Add 10 pixel gap between tick and label.
                context.fillText(params.titleText,10,chartHeight*.3);
                //context.textAlign = "right";
		//context.fillText(params.maxValueText, chartWidth,(chartHeight * 0.55)+10);
		//context.fillText(params.maxValue/2,15+(chartWidth*0.5),(chartHeight * 0.70)+10);

		return this.each(function() {
		
		//TODO:  Number of ticks
		//TODO:  Fix problem where
		//TODO:  Specify colors.
		//TODO:  Test different sizes
		//TODO:  Think about other stuff (descending axis value,  vertical bullet, font size)
		});
	}
	
})(jQuery);
