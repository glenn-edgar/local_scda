 
 
function system_state_init()
{    var g,h,i
     var alarm_data;
     var  queue_interval_id;
     var  nintervalId;
     var data = [];
     var conversion_factor_index;
     var conversion_factor;
     var conversion_factor_array;


     var ajax_success = function(data)
     {
       var temp
       var temp_1
       var tempDate

       var date = new Date( data.sprinkler_time_stamp  * 1000);
       tempDate = new Date()
       
       $("#time_stamp").html("Time:  "+tempDate.toLocaleDateString() + "   " + tempDate.toLocaleTimeString() )

       $("#controller_time_stamp").html("Ctr Time: "+ date.toLocaleDateString() + "   " + date.toLocaleTimeString() )
       $("#flow_rate").html("GPM:  "+data.global_flow_sensor);
       $("#op_mode_a").html("Mode: "+data.sprinkler_ctrl_mode)
       $("#schedule").html("Schedule: "+data.schedule_name)
       $("#step").html("Step:   "+data.schedule_step)
       $("#time").html("Step Time:  "+data.schedule_time_max)
       $("#duration").html("Duration: "+data.schedule_time_count) 
       $("#rain_day").html("Rain Day: "+data.rain_day)
       $("#coil_current").html("Coil ma: "+data.coil_current)
       $("#master_valve").html("Master Valve: "+data.MASTER_VALVE_SETUP )
       $("#eto_management").html("ETO Management: "+data.ETO_MANAGE_FLAG )
       $("#suspend").html("Suspension State:  "+data.SUSPEND )

     }

     status_request = function()
     {
            json_object = []
            key_list = ["sprinkler_time_stamp","global_flow_sensor", "sprinkler_ctrl_mode","schedule_name","schedule_step","schedule_time_max",
                        "schedule_time_count","rain_day","coil_current","MASTER_VALVE_SETUP","ETO_MANAGE_FLAG","SUSPEND" ]
            var json_string = JSON.stringify(key_list);
            
            $.ajax({
                    type: "POST",
                    url: '/ajax/get_redis_keys',
                    dataType: 'json',
                    async: false,
                    contentType: "application/json",
                    data: json_string,
                    success: ajax_success,
                    error: function () 
		    {
		      
                       alert('/ajax/get_status'+"  Server Error Request Not Successful");
		   
		       
                    }
              })
           
	  
     }
 
    

   $( "#status_panel"  ).bind({ popupafteropen: status_request })


  } 
system_state_init()

