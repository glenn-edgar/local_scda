#!/usr/bin/env python
from werkzeug.testsuite import main
main()
