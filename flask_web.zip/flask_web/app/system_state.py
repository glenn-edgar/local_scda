import json 

import redis
import base64

class System_Status():

   def __init__(self,redis_handle ):
       self.redis_handle = redis_handle
       pass

   def save_eto_data( self, json_object ):
 
       for j in  json_object:
           self.redis_handle.set(j["name"],j["data"])
       return json.dumps("SUCCESS")
 


   def get_eto_entries( self, *args ):
  
  
       json_object = []
     
       eto_dictionary = self.redis_handle.get(  "ETO_RESOURCE_LIST")
       eto_list = eto_dictionary.split(":")
  
       for j in eto_list:
           temp = {}
           temp["name"] = j
           temp["data"]  = self.redis_handle.get( j )
           json_object.append(temp)
     
     
       json_string = json.dumps( json_object )

       return json_string
 


   def generate_steps( self, file_data):
  
       returnValue = []
       controller_pins = []
       if file_data["schedule"] != None:
           schedule = file_data["schedule"]
           for i  in schedule:
               returnValue.append(i[0][2])
               temp = []
               for l in  i:
	           temp.append(  [ l[0], l[1][0] ] )
               controller_pins.append(temp)
  
  
       return len(returnValue), returnValue, controller_pins



   def schedule_data( self, *args):
    
       json_data=open("/media/mmc1/app_data_files/sprinkler_ctrl.json")
       sprinkler_ctrl = json.load(json_data)
       returnValue = []
       for j in sprinkler_ctrl:
    
           json_data=open("/media/mmc1/app_data_files/"+j["link"])
           temp = json.load(json_data)
           j["step_number"], j["steps"], j["controller_pins"] = self.generate_steps(temp)
           returnValue.append(j)
  

       return json.dumps(returnValue)

   def mode_change( self, json_object ):
      
       json_object["step"]       = int(json_object["step"])
       json_object["run_time"]   = int(json_object["run_time"])

       json_string = json.dumps(json_object)
       print "json_string",json_string
       self.redis_handle.lpush("sprinkler_ctrl_queue", base64.b64encode(json_string) )
       return json.dumps("SUCCESS")





   def get_queue_entry( self, *args ):

     json_object = []
     length =   self.redis_handle.llen( "IRRIGATION_QUEUE" )
     if length > 0 :
        name      = "unspecified"
        total     = 0
        for i in  range(0, length):
           data = self.redis_handle.lindex( "IRRIGATION_QUEUE", length-1  -i)
           
           if data != None :
	     data = json.loads(data)
             if  data["type"] == "END_SCHEDULE" :
	        element = {}
	        name = data["schedule_name"]
	        element["name"]   = name
	        element["value"]  = total
	        json_object.append( element)
	        element_list = []
	        element_list.append(total)
	        name = "unspecified"
	        total = 0
	
	     if data["type"] == "IRRIGATION_STEP" :
	       total = total + int( data["run_time"])
	 

      
        if total > 0 :
      	   element = {}    
	   element["name"]   = name
	   element["value"]  = total
	   json_object.append(element)
    

  
     json_string = json.dumps(json_object)
    
     return json_string
 

 
   def delete_queue( self, *args ):
  
       length =   self.redis_handle.llen( "IRRIGATION_QUEUE" )
       if length > 0 :
           queue_index = 0
           for i in range(0,length):
               queue_index_temp = queue_index
               data = self.redis_handle.lindex( "IRRIGATION_QUEUE", length - 1 -i)
               if data != None:
	           data = json.loads(data)
                   if  data["type"] == "END_SCHEDULE" :
                       queue_index_temp = queue_index +1 
                   if json_object[ queue_index ] != 0 :
                       self.redis_handle.lset( "IRRIGATION_QUEUE",length - 1 -i,"NULL/NULL")
                       self.redis_handle.lrem( "IRRIGATION_QUEUE", 1, "NULL/NULL" )
                      
                
               queue_index = queue_index_temp
        

       json_string = json.dumps("SUCCESS")
       return json_string


