import json as simplejson
import json
import time
import os
import cherrypy
from urlparse import *
from shutil import *
import urllib
from cherrypy.lib.httputil import parse_query_string

import redis
from types import *


class Statistics_Module:

   def __init__( self ,redis_handle):
         self.redis_handle            = redis_handle
         self.schedule_data           = self.get_schedule_data()
         self.sensor_names            = self.get_flow_rate_sensor_names()
         self.conversion_rate         = self.get_conversion_rates()
         self.flow_rate_sensor_names  = self.get_flow_rate_sensor_names()
   
   
   def get_schedule_data( self, *args):
    
     json_data=open("../app_data_files/sprinkler_ctrl.json")
     sprinkler_ctrl = json.load(json_data)
     returnValue = {}
     for j in sprinkler_ctrl:
    
         json_data=open("../app_data_files/"+j["link"])
         temp = json.load(json_data)
         j["step_number"], j["steps"], j["controller_pins"] = self.generate_steps(temp)
         returnValue[j["name"]] = j
     return returnValue

   def generate_steps( self, file_data):
       returnValue = []
       controller_pins = []
       if file_data["schedule"] != None:
         schedule = file_data["schedule"]
         for i  in schedule:
             returnValue.append(i[0][2])
             temp = []
             for l in  i:
	       temp.append(  [ l[0], l[1][0] ] )
             controller_pins.append(temp)
  
  
       return len(returnValue), returnValue, controller_pins



   def get_flow_limit_values_a( self, step_number, sensor_name, schedule_name ):
       key = "log_data:flow_limits:"+schedule_name+":"+sensor_name
       data = self.redis_handle.get( key )
       if data == None:
	   returnValue = self.generate_default_limits( step_number )
       else:
           returnValue = json.loads(data)
       return returnValue

   def generate_default_limits( self, step_number ):
       returnValue = []
       for i in range(0,step_number):
           temp = {}
           temp["limit_avg"] = 0
           temp["limit_std"] = 0
           returnValue.append(temp)
    
       return returnValue

   def get_flow_rate_sensor_names( self, data_file_path = "../system_data_files/global_sensors.json" ):
       return_data = []
       json_data=open(data_file_path)
       data = json.load(json_data)
       for i in data:
           
           return_data.append(i[0])

       return return_data


   def get_conversion_rates( self, data_file_path = "../system_data_files/global_sensors.json" ):
       return_data = []
       json_data=open(data_file_path)
       data = json.load(json_data)
   
       for i in data:
           
           return_data.append(i[3])

       return return_data

   def get_average_flow_data( self,  step_number, sensor_name, schedule_name ):  
       returnValue = []
       for i in range(0,step_number):
           key = "log_data:flow:"+schedule_name+":"+str(i+1)
           value_array = []
           for j in range(0,3):
               composite_string = self.redis_handle.lindex(key,j)
               try:
                   composite_object = json.loads( composite_string )
 	           value = composite_object["fields"][sensor_name]["average"] 
               
               except:
                   value = 0
               value_array.append(value)
           returnValue.append(value_array)   
       return returnValue

   def get_average_flow_data_queue( self,  step_id, sensor_name, schedule_name ):  
       
       
       key = "log_data:flow:"+schedule_name+":"+str(step_id+1)
       value_array = []
       number = self.redis_handle.llen(key)
       
       for j in range(0,number):
           composite_string = self.redis_handle.lindex(key,j)
           try:
               composite_object = json.loads( composite_string )
               
 	       value =  [ composite_object["time"], composite_object["fields"][sensor_name]["average"] ]
           except:
               value = [ 0,0]
           value_array.append(value)
       
       value_array.reverse()    
       return value_array



   def get_flow_limit_values( self, step_number, sensor_name, schedule_name ):
       
      
       key = "log_data:flow_limits:"+schedule_name+":"+sensor_name
       data = self.redis_handle.get( key )
       if data == None:
           returnValue = self.generate_default_limits( step_number )
       else:
           returnValue = json.loads(data)
       return returnValue        
 
   def get_current_data( self, step_number, schedule_name ):
       returnValue = []
       for i in range(0,step_number):
           key = "log_data:coil:"+schedule_name+":"+str(i+1)
           value_array = []
           for j in range(0,3):
               composite_string = self.redis_handle.lindex(key,j)
              
               try:
                   composite_object = json.loads( composite_string )
 	           value = composite_object["fields"]["coil_current"]["average"] 
               
               except:
                   value = 0
               value_array.append(value)
           returnValue.append(value_array)   
       return returnValue



 

   def get_current_limit_values( self,  step_number, schedule_name ):
       key = "log_data:coil_limits:"+schedule_name
       data = self.redis_handle.get( key )
       if data == None:
	   returnValue = self.generate_default_limits( step_number )
       else:
           returnValue = json.loads(data)
       return returnValue

   def get_time_index_flow( self,time_id, step_id, sensor_name, schedule_name ):
       key = "log_data:flow:"+schedule_name+":"+str(step_id+1)
       returnValue = []
       count = 0
       for i in range(time_id,time_id+5):
           composite_string = self.redis_handle.lindex(key,i)
           
           if composite_string == None:
	       returnValue.append([])
           else:
	       try:
	           composite_object = json.loads( composite_string )
                   
	           temp = {}
                   
	           if type( composite_object["fields"]) is   DictType:
                        
                       returnValue.append(composite_object["fields"][sensor_name])
                       
                   else:
                       returnValue.append(None)
                       
	       except:
	           returnValue.append(None)
                   
	   count = count +1
       

       print "return Value",returnValue
       return returnValue

   def get_average_current_data_queue( self, step_id,  schedule_name ):
      
       key = "log_data:coil:"+schedule_name+":"+str(step_id+1)
       value_array = []
       number = self.redis_handle.llen(key)
       
       for j in range(0,number):
           composite_string = self.redis_handle.lindex(key,j)
           try:
               composite_object = json.loads( composite_string )
               
 	       value =  [ composite_object["time"], composite_object["fields"]["coil_current"]["average"] ]
           except:
               value = [ 0,0]
           value_array.append(value)
       
       value_array.reverse()  
       
       return value_array


   def get_time_index_current( self, time_id, step_id,  schedule_name ):
       key = "log_data:coil:"+schedule_name+":"+str(step_id+1)
       returnValue = []
       count = 0
       for i in range(time_id,time_id+5):
           composite_string = self.redis_handle.lindex(key,i)
           
           if composite_string == None:
	       returnValue.append([])
           else:
	       try:
	           composite_object = json.loads( composite_string )
                   
	           temp = {}
                   
	           if type( composite_object["fields"]) is   DictType:
                        
                       returnValue.append(composite_object["fields"]["coil_current"])
                       
                   else:
                       returnValue.append(None)
                       
	       except:
	           returnValue.append(None)
                   
	   count = count +1
       

       print "return Value",returnValue
       return returnValue

   def get_total_flow_data( self,  step_number, sensor_name, schedule_name ):     
   
       returnValue = []
       key = "log_data:flow:"+schedule_name+":"+str(step_number+1)
       index = self.redis_handle.llen(key)
       for i in range(0,index):
           composite_string = self.redis_handle.lindex(key,i)
           if composite_string == None:
	       pass # do nothing
       	   
           else:
	       try:
	           composite_object = json.loads( composite_string )
                   returnValue.append( [ composite_object["time"], composite_object["fields"][sensor_name]["total"] ] )
               except:
                   pass # do nothing

       returnValue.reverse() 
       return returnValue
   
   '''   
  def get_flow_queue_size( self, url_list, redis_handle, cherrypy ):
      query_string = cherrypy.request.query_string
      json_string = urllib.unquote(query_string)
      json_object = json.loads(json_string)
      schedule_name = json_object["schedule"]
      step_number = int(json_object["step"])
      key = "log_data:flow:"+schedule_name+":"+str(step_number+1)
      return json.dumps(redis_handle.llen(key))

  def get_flow_data( self, url_list, redis_handle, cherrypy ):
    
      query_string = cherrypy.request.query_string
      json_string = urllib.unquote(query_string)
      json_object = json.loads(json_string)
      schedule_name = json_object["schedule"]
      step_number = int(json_object["step"])
      flow_sensor = json_object["flow_sensor"]
      index = 	    int(json_object["index"])
     
      
      key = "log_data:flow:"+schedule_name+":"+str(step_number+1)
      composite_string = redis_handle.lindex(key,index)
     
      if composite_string == None:
	 temp = {}
         temp["count"] = 0
      else:
	try:
	   composite_object = json.loads( composite_string )
	   temp = {}
	   time_temp = composite_object["time"]
	   if type( composite_object["fields"]) is   DictType: 
              temp = composite_object["fields"][flow_sensor]
           else:
              temp["count"] = 0
          
           temp["time"] = time_temp
        except:
	   temp = {}
           temp["count"] = 0

        
      returnValue = json.dumps(temp)
      
      return returnValue

  def get_flow_limit_values( self, redis_handle, step_number, sensor_name, schedule_name ):
      key = "log_data:flow_limits:"+schedule_name+":"+sensor_name
      data = redis_handle.get( key )
      if data == None:
	returnValue = self.generate_default_limits( step_number )
      else:
        returnValue = json.loads(data)
      return returnValue

  def generate_default_limits( self, step_number ):
    returnValue = []
    for i in range(0,step_number):
      temp = {}
      temp["limit_avg"] = 0
      temp["limit_std"] = 0
      returnValue.append(temp)
    
    return returnValue


  def get_flow_trend_data( self, url_list, redis_handle, cherrypy ):

      query_string = cherrypy.request.query_string
      json_string = urllib.unquote(query_string)
      json_object = json.loads(json_string)
      schedule_name = json_object["schedule"]
      step_number = int(json_object["step"])
      flow_sensor = json_object["flow_sensor"]
      index = 	    int(json_object["index"])
     
      
      key = "log_data:flow:"+schedule_name+":"+str(step_number+1)
      returnValue = {}
      count = 0
      for i in range(index,index+5):
         composite_string = redis_handle.lindex(key,i)
         if composite_string == None:
	   returnValue[count] = None
         else:
	    try:
	       composite_object = json.loads( composite_string )
	       temp = {}
	       if type( composite_object["fields"]) is   DictType: 
                   returnValue[count] = composite_object["fields"][flow_sensor]
               else:
                  returnValue[count] = None
	    except:
	         returnValue[count] = None
	 count = count +1
	 
      temp = self.get_flow_limit_values( redis_handle, step_number, flow_sensor, schedule_name ) 
      if temp == None:
	
	returnValue["limits"] = None
      elif  len( temp) <= step_number:
        returnValue["limits"] = None
      else:
       returnValue["limits"] = temp[step_number]  
        
      returnValue = json.dumps( returnValue)
      
      return returnValue
    
    
  def get_average_flow_data( self, url_list, redis_handle, cherrypy ):

     query_string = cherrypy.request.query_string
     json_string = urllib.unquote(query_string)
     json_object = json.loads(json_string)
     schedule_name = json_object["schedule"]
     step_number = int(json_object["step"])
     flow_sensor = json_object["flow_sensor"]
     
     returnValue = {}
     returnValue["data"] = []
     key = "log_data:flow:"+schedule_name+":"+str(step_number+1)
     index = redis_handle.llen(key)
     for i in range(0,index):
       composite_string = redis_handle.lindex(key,i)
       if composite_string == None:
	  pass # do nothing
       	   
       else:
	    try:
	      composite_object = json.loads( composite_string )
	      if type( composite_object["fields"]) is   DictType: 
	        
                returnValue["data"].append( [ composite_object["time"], composite_object["fields"][flow_sensor]["average"] ] )
            except:
                pass # do nothing

     temp = self.get_flow_limit_values( redis_handle, step_number, flow_sensor, schedule_name ) 
     if temp == None:
	returnValue["limits"] = None
     elif  len( temp) <= step_number:
        returnValue["limits"] = None
     else:
       returnValue["limits"] = temp[step_number]     
     
     returnValue = json.dumps( returnValue)
      
     return returnValue
      
      
  def get_total_flow_data( self, url_list, redis_handle, cherrypy ):    
     query_string = cherrypy.request.query_string
     json_string = urllib.unquote(query_string)
     json_object = json.loads(json_string)
     schedule_name = json_object["schedule"]
     step_number = int(json_object["step"])
     flow_sensor = json_object["flow_sensor"]
     
     returnValue = {}
     returnValue["data"] = []
     key = "log_data:flow:"+schedule_name+":"+str(step_number+1)
     index = redis_handle.llen(key)
     for i in range(0,index):
       composite_string = redis_handle.lindex(key,i)
       if composite_string == None:
	  pass # do nothing
       	   
       else:
	    try:
	      composite_object = json.loads( composite_string )
	      if type( composite_object["fields"]) is   DictType: 
	       
                returnValue["data"].append( [ composite_object["time"], composite_object["fields"][flow_sensor]["total"] ] )
            except:
                pass # do nothing

  
     
     returnValue = json.dumps( returnValue)
      
     return returnValue
          
    


  def get_coil_data( self, url_list, redis_handle, cherrypy ):
    
      query_string = cherrypy.request.query_string
      json_string = urllib.unquote(query_string)
      json_object = json.loads(json_string)
      schedule_name = json_object["schedule"]
      step_number = int(json_object["step"])
 
      index = 	    int(json_object["index"])
     
      
      key = "log_data:coil:"+schedule_name+":"+str(step_number+1)
      composite_string = redis_handle.lindex(key,index)
        
      if composite_string == None:
	 temp = {}
         temp["count"] = 0
      else:
	try:
	   composite_object = json.loads( composite_string )
	   temp = {}
	   time_temp = composite_object["time"]
	   if type( composite_object["fields"]) is   DictType: 
              temp = composite_object["fields"]["coil_current"]
           else:
              temp["count"] = 0
          
           temp["time"] = time_temp
        except:
	   temp = {}
           temp["count"] = 0

        
      returnValue = json.dumps(temp)
      
      return returnValue
    
    

  def coil_queue_size( self, url_list, redis_handle, cherrypy ):

      query_string = cherrypy.request.query_string
      json_string = urllib.unquote(query_string)
      json_object = json.loads(json_string)
      schedule_name = json_object["schedule"]
      step_number = int(json_object["step"])
      key = "log_data:coil:"+schedule_name+":"+str(step_number+1)
      return json.dumps(redis_handle.llen(key))
    
    
  def get_coil_trend_data( self, url_list, redis_handle, cherrypy ):

      query_string = cherrypy.request.query_string
      json_string = urllib.unquote(query_string)
      json_object = json.loads(json_string)
      schedule_name = json_object["schedule"]
      step_number = int(json_object["step"])
      index = 	    int(json_object["index"])
     
      
      key = "log_data:coil:"+schedule_name+":"+str(step_number+1)
      returnValue = {}
      count = 0
      for i in range(index,index+5):
         composite_string = redis_handle.lindex(key,i)
         if composite_string == None:
	   returnValue[count] = None
         else:
	    try:
	       composite_object = json.loads( composite_string )
	       temp = {}
	       if type( composite_object["fields"]) is   DictType: 
                   returnValue[count] = composite_object["fields"]["coil_current"]
               else:
                  returnValue[count] = None
	    except:
	         returnValue[count] = None
	 count = count +1
	 
      temp = self.get_current_limit_values( redis_handle, step_number,  schedule_name ) 
      if temp == None:
	
	returnValue["limits"] = None
      elif  len( temp) <= step_number:
        returnValue["limits"] = None
      else:
       returnValue["limits"] = temp[step_number]  
        
      returnValue = json.dumps( returnValue)
      
      return returnValue
    
    
  def get_average_coil_data( self, url_list, redis_handle, cherrypy ):

     query_string = cherrypy.request.query_string
     json_string = urllib.unquote(query_string)
     json_object = json.loads(json_string)
     schedule_name = json_object["schedule"]
     step_number = int(json_object["step"])
    
     
     returnValue = {}
     returnValue["data"] = []
     key = "log_data:coil:"+schedule_name+":"+str(step_number+1)
     index = redis_handle.llen(key)
     for i in range(0,index):
       composite_string = redis_handle.lindex(key,i)
       if composite_string == None:
	  pass # do nothing
       	   
       else:
	    try:
	      composite_object = json.loads( composite_string )
	      if type( composite_object["fields"]) is   DictType: 
	      
                returnValue["data"].append( [ composite_object["time"], composite_object["fields"]["coil_current"]["average"] ] )
            except:
                pass # do nothing

     temp = self.get_current_limit_values( redis_handle, step_number,  schedule_name ) 
     if temp == None:
	returnValue["limits"] = None
     elif  len( temp) <= step_number:
        returnValue["limits"] = None
     else:
       returnValue["limits"] = temp[step_number]     
     
     returnValue = json.dumps( returnValue)
      
     return returnValue
    
  def get_current_limit_values( self, redis_handle, step_number, schedule_name ):
      key = "log_data:coil_limits:"+schedule_name
      data = redis_handle.get( key )
      if data == None:
	returnValue = self.generate_default_limits( step_number )
      else:
        returnValue = json.loads(data)
      return returnValue
   '''
 
